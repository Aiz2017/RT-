/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-03     TRF       the first version
 */

/****************数据库****************/

#include "DataBase.h"

SensorData     Sensor_Data;


